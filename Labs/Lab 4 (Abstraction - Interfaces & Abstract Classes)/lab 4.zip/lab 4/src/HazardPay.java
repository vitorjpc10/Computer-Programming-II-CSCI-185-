public class HazardPay extends PayCalculator {

	
	public double computePay(int hours) {
		
		return (payRate * hours) * 1.5;
		
	}
	
	

}
