
public class BulkDiscount extends DiscountPolicy {

	int minimum;
	double percent;

	public BulkDiscount(int min, double percent)
	{
		minimum = min;
		percent = this.percent;
	}
	
	public double computeDiscount(int count, double itemCost) {
		
		if(count > minimum)
			return itemCost/percent;
		else
		{
			System.out.println("The quantity of purchased if an item is less than the minimum. Returning '0'");
			return 0;
		}
	}

	
}
