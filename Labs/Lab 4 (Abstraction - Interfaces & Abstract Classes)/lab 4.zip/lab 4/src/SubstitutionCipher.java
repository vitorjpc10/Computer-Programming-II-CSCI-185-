
public class SubstitutionCipher implements MessageEncoder {

	int shift;

	public SubstitutionCipher(int shift) {
		this.shift = shift;
	}

	public String encode(String plainText)
	{
		String message = "";

		for (int i = 0; i < plainText.length(); i++)
		{
			System.out.println("The Char is:  " + plainText.charAt(i));

			
			if ((i + shift) > plainText.length())
				break;
			
			if((i+shift) < plainText.length())
			{
				message = message.concat("" + plainText.charAt(i + shift));
			}
			
		}

		return message;
	}

}
