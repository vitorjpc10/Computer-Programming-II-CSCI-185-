

public abstract class PayCalculator {
	
	double payRate;
	
	public abstract double computePay(int hours);

}
