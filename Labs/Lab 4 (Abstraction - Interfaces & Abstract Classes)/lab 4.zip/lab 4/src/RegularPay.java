
public abstract class RegularPay extends PayCalculator {

	public RegularPay(double payRate) {
		this.payRate = payRate;
	}	
}
