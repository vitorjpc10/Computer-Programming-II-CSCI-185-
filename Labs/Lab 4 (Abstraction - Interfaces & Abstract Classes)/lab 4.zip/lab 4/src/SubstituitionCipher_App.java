
public class SubstituitionCipher_App {
	
	public static void main(String[] args)
	{
		
		SubstitutionCipher x = new SubstitutionCipher(10);
		
		String original = "hdosgsqoq9HI! :)";
		
		
		String code = x.encode(original);
		System.out.println("The encoded code is: " + code);
	}

}
