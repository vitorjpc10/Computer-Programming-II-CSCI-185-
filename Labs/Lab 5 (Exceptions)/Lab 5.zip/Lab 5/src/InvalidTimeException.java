public class InvalidTimeException extends Exception{
	
	public String reason;
	
	public InvalidTimeException(String reason) 
	{
		super(reason);
	}
}
