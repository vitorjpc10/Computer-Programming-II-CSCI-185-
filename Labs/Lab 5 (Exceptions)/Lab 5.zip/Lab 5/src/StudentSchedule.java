import java.util.Arrays;

public class StudentSchedule{

	private String[] scheduleTimes;

	public StudentSchedule()
	{
		scheduleTimes = new String[6];
	}

	public String[] getScheduleTimes() 
	{
		return scheduleTimes;
	}

	public void setScheduleTimes(String[] scheduleTimes)
	{
		this.scheduleTimes = scheduleTimes;
	}

	public void insertClass(int time, String className) throws TimeInUseException, InvalidTimeException
	{
		if((time < 1) || (time > 6))
			throw new InvalidTimeException("Invalid time, time is not between 1 and 6 p.m.");

		if(scheduleTimes[time - 1] != null)
			throw new TimeInUseException("This time slot is already occupied.");

		scheduleTimes[time-1] = className;

	}


	public String toString() {
		return "StudentSchedule [scheduleTimes=" + Arrays.toString(scheduleTimes) + "]";
	}




}
