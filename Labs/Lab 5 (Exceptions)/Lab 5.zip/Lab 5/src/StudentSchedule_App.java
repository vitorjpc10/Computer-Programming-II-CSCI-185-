import java.util.Scanner;


public class StudentSchedule_App 
{
	public static void main(String[] args) throws InvalidTimeException, TimeInUseException 
	{
		Scanner keyboard = new Scanner(System.in); 
		StudentSchedule student = new StudentSchedule();

		boolean full = false;
		

		while(!full)
		{

			try 
			{
				System.out.println("Please enter the time and class name you wish to enroll in the following format:" + "\n" + " 'time' 'class name'" + "\n" + "  e.g. 4 Biology" );

				int classTime = keyboard.nextInt();
				String className = keyboard.nextLine();

				student.insertClass(classTime, className);

			}
			catch(TimeInUseException exp)
			{
				System.out.println("The time slot is already taken. Please enter a different time: ");
			
			
				
			}
			catch(InvalidTimeException exc) 
			{
				System.out.println("The time is out of the range. Please input a time between 1 and 6 p.m.");
			
			}
			catch(java.util.InputMismatchException x)
			{
				System.out.println("One or more inputs are invalid. Please enter the inputs in the correct format. e.g. 6 Physics");
				keyboard.nextLine();
				
			}
			finally
			{
				System.out.println(student.toString() + "\n");

				int nullCounter = 0;

				for(int i = 0; i < student.getScheduleTimes().length; i++)
				{
					if(student.getScheduleTimes()[i] == null)
						nullCounter++;
				}

				if(nullCounter == 0)
				{
					full = true;
					System.out.println("All time slots between 1pm and 6pm are filled!");
				}

				nullCounter = 0;
			}
		}











		//		System.out.println("class time is: " + classTime + "class name is: " + className);
		//		System.out.println(student.toString());



	}

}
