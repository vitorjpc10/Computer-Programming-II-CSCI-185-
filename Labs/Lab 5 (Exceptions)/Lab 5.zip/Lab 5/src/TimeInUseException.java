
public class TimeInUseException extends Exception{
	
	public String reason;
	
	public TimeInUseException(String reason)
	{
		super(reason);
	}

}
