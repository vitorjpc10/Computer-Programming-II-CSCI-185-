import java.util.Scanner;

public class Remainder_App {

	public static void main(String[] args)
	{

		Scanner keyboard = new Scanner(System.in); 

		System.out.println("Please enter 2 integer values you wish to calculate with a space separating them:");
		int value1 = 0;
		int value2 = 0;
		boolean invalidInputs = false;


		while(!invalidInputs)
		{
			try {

				value1 = keyboard.nextInt();
				value2 = keyboard.nextInt();
				invalidInputs = true;

			}
			catch (java.util.InputMismatchException exc)
			{
				System.out.println("One or more of the values you have entered is not an integer. " + "\n" + "Please enter 2 integer values:");
				invalidInputs = false;
				keyboard.nextLine();
				
			}
		}






		int num1 = value1;
		int num2 = value2;


		Remainder x = new Remainder();


		System.out.println(value1 + " % "+ value2 + " = " + x.computeRemainder(num1, num2));
	}
}






