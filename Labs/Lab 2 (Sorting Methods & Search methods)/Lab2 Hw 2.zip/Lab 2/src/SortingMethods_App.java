import java.util.Scanner;

public class SortingMethods_App 
{
	public static void main(String[] args)
	{
		SortingMethods x = new SortingMethods();
		Scanner keyboard = new Scanner(System.in); 
		
		
		System.out.println("Please enter 10 intenger values to be inserted into the array:");
		
		for(int i = 0; i < x.getArray().length; i++)
		{
			x.intInsert(keyboard.nextInt());
		}
		
		
		System.out.println("The array is: ");
		for(int i = 0; i < x.getArray().length; i++)
		{
			System.out.println("Value at index " + i + " is: " + x.getArray()[i]);
		}
		
		System.out.println("\n");
		
		System.out.println("The array through BubbleSort is: ");
		x.bubbleSort(x.getArray());
		for(int i = 0; i < x.getArray().length; i++)
		{
			System.out.println("Value at index " + i + " is: " + x.getArray()[i]);
		}
		
		
		System.out.println("\n");
		
		System.out.println("The array through SelectiveSort is: ");
		x.selectionSort(x.getArray());
		for(int i = 0; i < x.getArray().length; i++)
		{
			System.out.println("Value at index " + i + " is: " + x.getArray()[i]);
		}
		
		System.out.println("\n");
		
		System.out.println("The array through InsertionSort is: ");
		x.insertionSort(x.getArray());
		for(int i = 0; i < x.getArray().length; i++)
		{
			System.out.println("Value at index " + i + " is: " + x.getArray()[i]);
		}
		
		System.out.println("Please enter the value you wish to search:");
		int searchValue = keyboard.nextInt();
		
		int searchIndex = x.binarySearch(x.getArray(), 0, x.getArray().length, searchValue);
		
		System.out.println("The index in which the value is located is: " + searchIndex);
		
		
		
		
	}
}
