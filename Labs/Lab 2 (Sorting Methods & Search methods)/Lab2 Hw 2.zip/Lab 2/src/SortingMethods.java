
public class SortingMethods {

	int[] array = new int[10];
	int arrayIndex = 0;

	public SortingMethods()
	{

	}

	public SortingMethods(int[] array) {
		this.array = array;
	}

	public int[] getArray() {
		return array;
	}

	public void setArray(int[] array) {
		this.array = array;
	}

	public void setArraySize(int size)
	{
		array = new int[size];
	}

	public void selectionSort(int[] array)
	{

	}

	public void intInsert(int number)
	{
		if((array[arrayIndex] == 0) && (arrayIndex < array.length))
		{
			array[arrayIndex] = number;
			arrayIndex++;
		}
	}

	public void swapBubble(int i, int[] array)
	{
		int temp;
		temp = array[i];
		array[i] = array[i+1];
		array[i+1] = temp;
	}

	public void bubbleSort(int[] array)
	{
		boolean sorted = false;

		while(!sorted)
		{

			for(int i = 0; i < array.length - 1; i++)
			{
				if(array[i] > array[i+1])
				{
					swapBubble(i, array);
					sorted = false;
				}

			}

			int sortedCheck = 0;

			for(int i = 0; i < array.length - 1; i++)
			{
				if(array[i] > array[i+1])
				{
					sortedCheck = 1;
				}

			}

			if(sortedCheck == 0)
				sorted = true;
			else
				sorted = false;

		}
	}

	public void swapSelective(int i, int minIndex, int[] array)
	{
		int temp = array[minIndex];
		array[minIndex] = array[i];
		array[i] = temp;
	}

	public void selectiveSort(int[] array)
	{
		for(int i = 0; i < array.length - 1;i++)
		{
			int smallestIndex = i;

			for(int j = i+1; j < array.length; j++)
			{
				if(array[j] < array[smallestIndex])
					smallestIndex = j;
			}

			swapSelective(i, smallestIndex, array);

		}
	}

	public void insertionSort(int[] array)
	{
		for(int i = 1; i < array.length; i++)
		{
			int indexValue = array[i];
			int indexBefore = i - 1;

			while(indexBefore >= 0 && array[indexBefore] > indexValue)
			{
				array[indexBefore + 1] = array[indexBefore];
				indexBefore = indexBefore -1;
			}

			array[indexBefore + 1] = indexValue;
		}
	}

	public int binarySearch(int[] array, int low, int high, int searchValue)
	{
		//it first checks if the array is sorted first
		int sortedCheck = 0;

		for(int i = 0; i < array.length - 1; i++)
		{
			if(array[i] > array[i+1])
				sortedCheck = 1;
		}

		if(sortedCheck == 1)
		{
			System.out.println("Array not sorted. Please sort the array first.");
			System.out.println("Returning '-1' ");
			return -1;
		}

		if(high >= low)
		{
			int mid = (low + (high - 1))/2;


			if(array[mid] == searchValue)
				return mid;

			if(array[mid] > searchValue)
				return binarySearch(array, low, mid - 1, searchValue);

			if(array[mid] < searchValue)
				return binarySearch(array, mid + 1, high, searchValue);

		}


		System.out.println("Unable to find the value in the array.");
		System.out.println("Returning '-1' ");
		return -1;


	}

}

