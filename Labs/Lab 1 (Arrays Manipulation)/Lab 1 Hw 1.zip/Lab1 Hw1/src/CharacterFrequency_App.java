import java.util.Scanner;

public class CharacterFrequency_App {



	public static void main(String[] args)
	{

		CharacterFrequency num = new CharacterFrequency();
		Scanner keyboard = new Scanner(System.in);

		System.out.println("Please, enter a 10 single digit numbers with a space in between them: ");
		num.storeNumber(keyboard.nextLine());

	/*	for(int i = 0; i < num.getNumber().length; i++)
		{
			System.out.println(num.getNumber()[i]);
		}
		
		*/

		System.out.println("Please, enter the number you wish to see the number of times it shows up:");
		int numInput = keyboard.nextInt();
		
		
		System.out.println("The number of times '" + numInput + "' appears in the telephone number is: " + num.numFrequecy(numInput));
		
		
	}
}
