import java.util.Scanner;

public class Ledger_App {
	public static void main(String[] args)
	{
		Ledger x = new Ledger();
		Scanner keyboard = new Scanner(System.in);
		
		System.out.println("Specify the the Maximum amount of sales that can be recorded: ");
		x.Ledger(keyboard.nextInt());
		
		//System.out.println("Max sales is: " + x.getMaxSales());
		
		x.setSale(x.getMaxSales());
		x.setSalesExceeded(x.getMaxSales());
		
		
		//System.out.println(x.getSale().length);
		
		System.out.println("Please enter the values of sales you wish to enter: ");
		
		for(int i = 0; i < x.getSale().length; i++)
		{
			x.addSale(keyboard.nextDouble());
		}
		
		
		/*for(int i = 0; i<x.getSale().length; i++)
		{
			System.out.println(x.getSale()[i]);
		} */
		
		System.out.println("Number of Sales made: " + x.getNumerOfSales());
		System.out.println("Total value of sales is: $" + x.getTotalSales());
		
		
		System.out.println("Average value of all sales is: $" + x.getAverageSale() + "\n");
		
		System.out.println("Specify a value to see the amount of sales that exceeded given value: ");
		double value = keyboard.nextDouble();
		
		System.out.println("The number os sales that exceeded $" + value + " is: " + x.getCountAbove(value) + " sales");
		System.out.println("\n" + "The sales who have exceeded the given value are: ");
		
		for(int i = 0; i< x.getSalesExceeded().length; i++)
		{
			if(x.getSalesExceeded()[i] != 0)
			System.out.println("Sale # " + i);
		}
		
	}
}
