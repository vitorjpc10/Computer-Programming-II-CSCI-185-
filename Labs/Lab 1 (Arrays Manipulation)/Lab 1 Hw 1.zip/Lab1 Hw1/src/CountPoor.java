
public class CountPoor {
	
	public static class Family{
		
		
		double income;
		int size;
		

		public Family() {
			
		}
		
		public Family(double income, int size) {
			super();
			this.income = income;
			this.size = size;
		}
		
		
		public double getIncome() {
			return income;
		}
		
		
		public void setIncome(double income) {
			this.income = income;
		}
		
		
		public int getSize() {
			return size;
		}
		
		
		public void setSize(int size) {
			this.size = size;
		}
		
		public boolean isPoor(double housingCost, double foodCost)
		{
			double totalCost = (housingCost + foodCost) * size;
			
			if(totalCost > (income/2))
				return true;
			else
				return false;
		}


		public String toString() {
			return "The Family consists of " + size + " Members in total and has a total income of $" + income + "\n";
		}
		
		
	}
}
