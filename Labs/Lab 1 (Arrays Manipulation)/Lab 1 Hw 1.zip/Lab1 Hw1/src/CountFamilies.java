
public class CountFamilies {

	int numFamilies = 0;
	double[] familiesArray;
	double maxValue;
	int familiesArrayIndex = 0;
	int[] lowIncomeArray;
	
	
	public CountFamilies()
	{
		
	}


	public CountFamilies(int numFamilies, double[] familiesArray, int max) {
		super();
		this.numFamilies = numFamilies;
		this.familiesArray = familiesArray;
		this.maxValue = max;
	}


	public int getNumFamilies() {
		return numFamilies;
	}


	public void setNumFamilies(int numFamilies) {
		this.numFamilies = numFamilies;
	}


	public double[] getFamiliesArray() {
		return familiesArray;
	}


	//Set the family array to a specific size
	public void setFamiliesArray(int count) {
		familiesArray = new double[count];
	}
	
	public int getFamiliesArraySize()
	{
		return familiesArray.length;
	}


	public double getMax() {
		return maxValue;
	}


	public void setMax(double max) {
		this.maxValue = max;
	}
	
	//receives an integer value and inserts it to the array.
	public void insertIncome(int income)
	{
		
		
		if((familiesArray[familiesArrayIndex] == 0) && (familiesArrayIndex < familiesArray.length))
		{
			familiesArray[familiesArrayIndex] = income;
			familiesArrayIndex++;
		}
		
		
	}
	
	//looks through the array and returns the highest value thus being the max
	public double calcMax(double[] array)
	{
		double max = 0;
		
		for(int i = 0; i < array.length; i++)
		{
			if(array[i] > max)
			max = array[i];
		}
		
		maxValue = max;
		return max; 
	}
	
	
	public int lessThanTen()
	{
		int count = 0;
		
		double percentage = maxValue/100;
		percentage = percentage * 10;
		
		for(int i = 0; i < familiesArray.length; i++)
		{
			if(familiesArray[i] < percentage) 
			{
				System.out.println("Family " + (i+1) + " has an income below 10% of the maximum: " + "Their income is $" + familiesArray[i]);
				count++;	
			}
			
		}
		
		return count;
	}

	

	public int[] getLowIncomeArray() {
		return lowIncomeArray;
	}


	public void setLowIncomeArray(int value) {
		lowIncomeArray = new int[value];
	}


}
	
	
	
	
