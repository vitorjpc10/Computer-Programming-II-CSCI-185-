import java.util.Scanner;


public class CountFamilies_App {
	public static void main(String[] args)
	{
		
		CountFamilies x = new CountFamilies();
		Scanner keyboard = new Scanner(System.in);
		
		
		System.out.println("Specify the number of families you desire to enter: ");
		x.setFamiliesArray(keyboard.nextInt());
		
		//System.out.println(x.getFamiliesArraySize());
		
		System.out.println("Please enter the income for the next " + x.getFamiliesArraySize() + " families:");
		
		for(int i = 0; i < x.getFamiliesArraySize(); i++)
		{
			x.insertIncome(keyboard.nextInt());
		}
		
		
	/*	for(int i = 0; i < x.getFamiliesArraySize(); i++)
		{
			System.out.println(x.getFamiliesArray()[i]);
		} */ 
		
		x.setLowIncomeArray(x.getFamiliesArraySize());
		
		double max = x.calcMax(x.getFamiliesArray());
		
		System.out.println("Out of the " + x.getFamiliesArray().length  +" families the max between them is: " + max);
	
		System.out.println("\n");
		
		
		System.out.println("\n" + "There are " + x.lessThanTen() + " families whose income is less than 10% the max.");
		
		
		
		
	}
	
}
