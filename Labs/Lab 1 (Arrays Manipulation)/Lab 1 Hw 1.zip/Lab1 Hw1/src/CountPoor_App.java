import java.util.Scanner;

public class CountPoor_App {
	
	public static void main(String[] args)
	{
		
		CountPoor.Family family = new CountPoor.Family(500, 3);
		Scanner keyboard = new Scanner(System.in);
		
		System.out.println(family.toString());
		
		
		System.out.println("Is the family Poor? ");
		
		boolean poorFlag = family.isPoor(500, 2);
		
		if(poorFlag = true)
			System.out.println("The family is poor");
		else
			System.out.println("The family is not poor");
		
	}
	
	

}
