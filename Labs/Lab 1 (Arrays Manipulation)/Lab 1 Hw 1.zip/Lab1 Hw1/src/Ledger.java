public class Ledger {
	
	double[] sale;
	int saleIndex = 0;
	int salesMade = 0;
	int maxSales;
	int[] salesExceeded;
	
	public Ledger()
	{
		
	}

	public Ledger(double[] sale, int salesMade, int maxSales) {
		
		this.sale = sale;
		this.salesMade = salesMade;
		this.maxSales = maxSales;
	}

	public double[] getSale() {
		return sale;
	}

	public int[] getSalesExceeded() {
		return salesExceeded;
	}

	public void setSalesExceeded(int size) {
		salesExceeded = new int[size];
	}

	public void setSale(int size) {
		sale = new double[size];
	}

	public void setSalesMade(int salesMade) {
		this.salesMade = salesMade;
	}

	public int getMaxSales() {
		return maxSales;
	}
	
	public void Ledger(int max) {
		maxSales = max;
	}
	
	public void addSale(double d)
	{
		sale[saleIndex] = d;
		saleIndex++;
	}
	
	public int getNumerOfSales() {
		
		int counter = 0;
		
		for(int i = 0; i <sale.length; i++)
		{
			if(sale[i] != 0)
				counter++;
		}
		
		salesMade = counter;
		return counter;
	}
	
	public double getTotalSales()
	{
		double total = 0;
		
		for(int i = 0; i <sale.length; i++)
		{
			if(sale[i] != 0)
				total += sale[i];
		}
		
		return total;
	}
	
	
	public double getAverageSale(){
		
		double total = 0;
		
		for(int i = 0; i <sale.length; i++)
		{
			if(sale[i] != 0)
				total += sale[i];
		}
		
		return (total/salesMade);
		
	}
	
	public int getCountAbove(double v)
	{
		int counter = 0;
		
		for(int i = 0; i <sale.length; i++)
		{
			if(sale[i] > v)
			{
				counter++;
				salesExceeded[i] = i+1;
			}
			
		}
		
		return counter;
	}

}



