
public class CharacterFrequency {
	
	int numTimes;
	int[] number = new int[10];
	
	public CharacterFrequency()
	{
		
	}

	public CharacterFrequency(int numTimes, int[] number) {
		super();
		this.numTimes = numTimes;
		this.number = number;
	}

	public int getNumTimes() {
		return numTimes;
	}

	public void setNumTimes(int numTimes) {
		this.numTimes = numTimes;
	}

	public int[] getNumber() {
		return number;
	}

	public void setNumber(int[] number) {
		this.number = number;
	}
	
	public void storeNumber(String num)
	{
		for(int i = 0; i < num.length(); i++)
		{
			number[i] = num.charAt(i) - '0';
		}
	}
	
	public int numFrequecy(int num)
	{
		int counter = 0;
		
		for(int i = 0; i < number.length; i++)
		{
			if(num == number[i])
				counter++;
		}
		
		return counter;
	}

}
