
public class ReferenceItem extends LibraryItem {
	
	String shelfLocation;

	public ReferenceItem()
	{
		super();
		
	}

	public ReferenceItem(String title, String author, String iSBN, String acquisitionDate, String trackingID, String shelfLocation)
	{
		super(title, author, iSBN, acquisitionDate, trackingID);
		this.shelfLocation = shelfLocation;
		
	}

	public String getShelfLocation() {
		return shelfLocation;
	}

	public void setShelfLocation(String shelfLocation) {
		this.shelfLocation = shelfLocation;
	}
	
	

}
