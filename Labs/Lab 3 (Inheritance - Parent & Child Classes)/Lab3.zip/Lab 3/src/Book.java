
public class Book extends CirculatingItem{

	public Book() {
		super();
		
	}

	public Book(String title, String author, String iSBN, String acquisitionDate, String trackingID, String borrower,
			String dateBorrowed, String dateDue, String deweyClassification) 
	{
		super(title, author, iSBN, acquisitionDate, trackingID, borrower, dateBorrowed, dateDue, deweyClassification);
		
	}

	
}
