
public class CirculatingItem extends LibraryItem{
	
	String borrower;
	String dateBorrowed;
	String dateDue;
	String deweyClassification;
	
	public CirculatingItem() {
		super();
		
	}
	
	public CirculatingItem(String title, String author, String iSBN, String acquisitionDate, String trackingID, String borrower, String dateBorrowed, String dateDue, String deweyClassification)
	{
		super(title, author, iSBN, acquisitionDate, trackingID);
		this.borrower = borrower;
		this.dateBorrowed = dateBorrowed;
		this.dateDue = dateDue;
		this.deweyClassification = deweyClassification;
	}

	public String getBorrower() {
		return borrower;
	}

	public void setBorrower(String borrower) {
		this.borrower = borrower;
	}

	public String getDateBorrowed() {
		return dateBorrowed;
	}

	public void setDateBorrowed(String dateBorrowed) {
		this.dateBorrowed = dateBorrowed;
	}

	public String getDateDue() {
		return dateDue;
	}

	public void setDateDue(String dateDue) {
		this.dateDue = dateDue;
	}

	public String getDeweyClassification() {
		return deweyClassification;
	}

	public void setDeweyClassification(String deweyClassification) {
		this.deweyClassification = deweyClassification;
	}
	
	
	
	

}
