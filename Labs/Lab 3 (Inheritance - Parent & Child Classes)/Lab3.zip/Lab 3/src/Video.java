
public class Video extends CirculatingItem{
	
	String director;

	
	public Video() {
		super();
	
	}

	
	public Video(String title, String author, String iSBN, String acquisitionDate, String trackingID, String borrower,
			String dateBorrowed, String dateDue, String deweyClassification, String director) 
	{
		super(title, author, iSBN, acquisitionDate, trackingID, borrower, dateBorrowed, dateDue, deweyClassification);
		this.director = director;
	}


	public String getDirector() {
		return director;
	}


	public void setDirector(String director) {
		this.director = director;
	}
	
	

}
