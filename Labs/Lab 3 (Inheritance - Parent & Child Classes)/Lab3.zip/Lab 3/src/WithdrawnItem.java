
public class WithdrawnItem extends LibraryItem {
	
	String withdrawnOn;

	public WithdrawnItem() {
		super();
		
	}

	public WithdrawnItem(String title, String author, String iSBN, String acquisitionDate, String trackingID, String withdrawnOn) {
		super(title, author, iSBN, acquisitionDate, trackingID);
		this.withdrawnOn = withdrawnOn;
		
	}

	public String getWithdrawnOn() {
		return withdrawnOn;
	}

	public void setWithdrawnOn(String withdrawnOn) {
		this.withdrawnOn = withdrawnOn;
	}
	
	
	
}
