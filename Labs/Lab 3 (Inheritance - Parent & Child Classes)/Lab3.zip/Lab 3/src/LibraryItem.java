
public class LibraryItem {
	
	String title;
	String author;
	String ISBN;
	String acquisitionDate;
	String trackingID;
	
	public LibraryItem()
	{
		
	}
	
	public LibraryItem(String title, String author, String iSBN, String acquisitionDate, String trackingID) {
		super();
		this.title = title;
		this.author = author;
		ISBN = iSBN;
		this.acquisitionDate = acquisitionDate;
		this.trackingID = trackingID;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getISBN() {
		return ISBN;
	}

	public void setISBN(String iSBN) {
		ISBN = iSBN;
	}

	public String getAcquisitionDate() {
		return acquisitionDate;
	}

	public void setAcquisitionDate(String acquisitionDate) {
		this.acquisitionDate = acquisitionDate;
	}

	public String getTrackingID() {
		return trackingID;
	}

	public void setTrackingID(String trackingID) {
		this.trackingID = trackingID;
	}
	
	

}
