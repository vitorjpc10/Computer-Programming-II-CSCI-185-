
public class CD extends CirculatingItem{
	
	String composer;

	
	public CD() {
		super();
		
	}

	public CD(String title, String author, String iSBN, String acquisitionDate, String trackingID, String borrower,
			String dateBorrowed, String dateDue, String deweyClassification, String composer) 
	{
		super(title, author, iSBN, acquisitionDate, trackingID, borrower, dateBorrowed, dateDue, deweyClassification);
		this.composer = composer;
	}

	public String getComposer() {
		return composer;
	}

	public void setComposer(String composer) {
		this.composer = composer;
	}
	
	

}
