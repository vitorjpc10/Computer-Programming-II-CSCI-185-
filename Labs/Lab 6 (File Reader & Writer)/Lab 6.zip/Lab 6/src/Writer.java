
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Scanner;

public class Writer {

	public static void main(String[] args) throws Exception
	{
		Scanner keyboard = new Scanner(System.in);


		try {
			BufferedWriter out = new BufferedWriter(new FileWriter("C:\\Users\\vitor\\eclipse-workspace\\Lab 6\\NamesWriter.txt"));
			boolean repeat = true;

			while(repeat)
			{

				System.out.println("Please write the word you desire: ");
				String word = keyboard.nextLine();

				out.write(word + ", ");

				System.out.println("Do you wish to enter another word?  [Y/N]");
				String input = keyboard.nextLine();

				if(input.equals("Y"))
					repeat = true;
				else
				{
					repeat = false;
					out.close();
				}

			}



		}
		catch(Exception e) 
		{
			e.printStackTrace();
		}





		try {
			BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\vitor\\eclipse-workspace\\Lab 6\\NamesWriter.txt"));

			String name;
			while((name = br.readLine()) != null)
				System.out.println(name);
		}
		catch (Exception x){
			x.printStackTrace();
		}




	}

}
