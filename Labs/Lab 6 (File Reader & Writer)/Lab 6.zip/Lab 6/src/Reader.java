import java.io.*;
import java.util.Scanner;


public class Reader {
	
	public static void main (String[] args) throws Exception
	{
		
		String filePath = new File("").getAbsolutePath();
		System.out.println(filePath);
		
		//Using the BufferedReader
		/* 
		try {
		BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\vitor\\eclipse-workspace\\Lab 6\\D&D Names.txt"));
		
		String name;
		while((name = br.readLine()) != null)
			System.out.println(name);
		}
		catch (Exception x){
			x.printStackTrace();
		}
		*/
		
		//Using Scanner
		Scanner sc = new Scanner(new File("C:\\Users\\vitor\\eclipse-workspace\\Lab 6\\D&D Names.txt"));
		
		while (sc.hasNextLine()) 
		      System.out.println(sc.nextLine()); 
		
	}
}
